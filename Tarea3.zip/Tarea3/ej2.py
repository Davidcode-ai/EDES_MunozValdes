# --- EJERCICIO 2: Interfaz Gráfica con Tkinter y Pygame ---
# Nombre: ejercicio2.py
# Asignatura: Entornos de Desarrollo
# Tema: 3
# Fecha: 06/11/2025

import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
import pygame
import math
import io
from PIL import Image, ImageTk 
# Ya no necesitamos 'base64'

# --- CLASE BARCO (Adaptada para la GUI) ---
# (Esta clase no cambia)
class Barco:
    """
    Versión adaptada de la clase Barco para la interfaz gráfica.
    """
    def __init__(self, nombre, posicionX, posicionY, velocidad, rumbo, numeroMunicion):
        self.nombre = nombre
        self.posicionX = float(posicionX)
        self.posicionY = float(posicionY)
        self.velocidad = 0.0
        self.rumbo = 1.0
        self.setVelocidad(velocidad)
        self.setRumbo(rumbo)
        self.numeroMunicion = int(numeroMunicion)
        self.canvas_id = None 

    def __str__(self):
        return (f"Barco: {self.nombre} | Pos: ({self.posicionX:.1f}, {self.posicionY:.1f}) | "
                f"Vel: {self.velocidad} km/h | Rumbo: {self.rumbo}° | Munición: {self.numeroMunicion}")

    def disparar(self):
        if self.numeroMunicion > 0:
            self.numeroMunicion -= 1
            return True
        else:
            return False

    def setVelocidad(self, nueva_velocidad):
        try:
            vel = float(nueva_velocidad)
            self.velocidad = max(0.0, min(20.0, vel))
        except ValueError:
            pass

    def setRumbo(self, nuevo_rumbo):
        try:
            rum = float(nuevo_rumbo)
            self.rumbo = max(1.0, min(359.0, rum))
        except ValueError:
            pass

    def agregar_municion(self, cantidad):
        try:
            cant = int(cantidad)
            if cant > 0:
                self.numeroMunicion += cant
        except ValueError:
            pass

# --- CLASE PRINCIPAL DE LA APLICACIÓN GUI ---

class FlotaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Simulador de Flota (Ejercicio 4 - Tema 3)")
        self.root.geometry("1000x700")

        self.lista_barcos = []
        self.barco_activo = None

        # 1. Inicializar Pygame para el audio
        self.iniciar_audio()

        # 2. Cargar icono del barco desde un archivo
        try:
            # --- ¡¡AQUÍ ESTÁ EL CAMBIO!! ---
            # Cargamos la imagen desde un archivo llamado "ship.png"
            # que debe estar en la misma carpeta que este script.
            img = Image.open("ship.png")
            
            # Forzamos la conversión a 'RGBA' (buena práctica para transparencias)
            img = img.convert("RGBA")

            # Comprobamos la versión de Pillow para compatibilidad de reescalado
            try:
                resample_method = Image.Resampling.LANCZOS
            except AttributeError:
                resample_method = Image.LANCZOS
            
            # Ajustamos el tamaño a 24x24 píxeles
            img = img.resize((24, 24), resample_method)
            
            # Convertimos la imagen de PIL a una imagen de Tkinter
            self.ship_icon = ImageTk.PhotoImage(img)
            
        except Exception as e:
            # Si falla, es probable que no se encuentre el archivo
            print("\n--- ERROR AL CARGAR 'ship.png' ---")
            print(f"¡ASEGÚRATE DE TENER EL ARCHIVO 'ship.png' EN LA MISMA CARPETA!")
            print(f"Error detallado: {e}")
            print("---------------------------------")
            
            messagebox.showerror("Error de Icono", 
                                 "No se pudo cargar el archivo 'ship.png'.\n"
                                 "Asegúrate de que el archivo existe en la carpeta del script.")
            self.root.destroy()
            return
        # --- FIN DE LA SECCIÓN MODIFICADA ---

        # 3. Configurar la interfaz
        self.crear_widgets()

        # 4. Iniciar el bucle de actualización del juego/movimiento
        self.actualizar_movimiento()

    def iniciar_audio(self):
        """Inicializa pygame.mixer y carga los sonidos."""
        try:
            pygame.mixer.init()
            pygame.mixer.music.load("background_music.mp3")
            pygame.mixer.music.set_volume(0.3) 
            pygame.mixer.music.play(loops=-1)
            self.sonido_disparo = pygame.mixer.Sound("cannon_shot.wav")
            self.sonido_disparo.set_volume(0.7)
            
        except Exception as e:
            messagebox.showwarning("Error de Audio", 
                f"No se pudieron cargar los archivos de sonido (pygame).\n"
                f"Asegúrate de tener 'background_music.mp3' y 'cannon_shot.wav' "
                f"en la misma carpeta que el script.\nError: {e}")

    def crear_widgets(self):
        """Crea y posiciona todos los elementos de la GUI."""
        
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        control_panel = ttk.Frame(main_frame, width=250, padding="10")
        control_panel.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.canvas = tk.Canvas(main_frame, bg="lightblue", relief=tk.SUNKEN, borderwidth=2)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.create_text(400, 300, text="Mar del Norte", 
                                font=("Arial", 30, "italic"), fill="navy")

        ttk.Button(control_panel, text="Crear Nuevo Barco", 
                   command=self.crear_nuevo_barco).pack(fill=tk.X, pady=5)
        
        ttk.Separator(control_panel, orient='horizontal').pack(fill=tk.X, pady=10)

        ttk.Label(control_panel, text="Seleccionar Barco Activo:").pack(anchor=tk.W)
        self.selector_var = tk.StringVar()
        self.selector_barco = ttk.Combobox(control_panel, 
                                           textvariable=self.selector_var, 
                                           state="readonly")
        self.selector_barco.pack(fill=tk.X, pady=5)
        self.selector_barco.bind("<<ComboboxSelected>>", self.seleccionar_barco_activo)

        ttk.Separator(control_panel, orient='horizontal').pack(fill=tk.X, pady=10)

        self.controles_activos_frame = ttk.Labelframe(control_panel, text="Controles del Barco")
        self.controles_activos_frame.pack(fill=tk.X, pady=5)

        ttk.Label(self.controles_activos_frame, text="Velocidad (0-20 km/h):").pack(anchor=tk.W, padx=5)
        self.entry_velocidad = ttk.Entry(self.controles_activos_frame)
        self.entry_velocidad.pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(self.controles_activos_frame, text="Establecer Velocidad", 
                   command=self.actualizar_barco_velocidad).pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(self.controles_activos_frame, text="Rumbo (1-359 °):").pack(anchor=tk.W, padx=5)
        self.entry_rumbo = ttk.Entry(self.controles_activos_frame)
        self.entry_rumbo.pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(self.controles_activos_frame, text="Establecer Rumbo", 
                   command=self.actualizar_barco_rumbo).pack(fill=tk.X, padx=5, pady=5)

        ttk.Label(self.controles_activos_frame, text="Añadir Munición:").pack(anchor=tk.W, padx=5)
        self.entry_municion = ttk.Entry(self.controles_activos_frame)
        self.entry_municion.pack(fill=tk.X, padx=5, pady=2)
        ttk.Button(self.controles_activos_frame, text="Recargar", 
                   command=self.actualizar_barco_municion).pack(fill=tk.X, padx=5, pady=5)

        self.boton_disparar = ttk.Button(self.controles_activos_frame, text="¡Disparar!", 
                                         command=self.llamar_disparar)
        self.boton_disparar.pack(fill=tk.X, padx=5, pady=15)
        
        self.estado_label = ttk.Label(self.controles_activos_frame, text="Seleccione un barco", 
                                      wraplength=230)
        self.estado_label.pack(fill=tk.X, padx=5, pady=10)

        self.habilitar_controles(False)

    def habilitar_controles(self, habilitar):
        estado = tk.NORMAL if habilitar else tk.DISABLED
        for child in self.controles_activos_frame.winfo_children():
            child.configure(state=estado)
        self.estado_label.configure(state=tk.NORMAL)


    def crear_nuevo_barco(self):
        nombre = simpledialog.askstring("Nuevo Barco", "Nombre del barco:", parent=self.root)
        if not nombre: return
        
        for b in self.lista_barcos:
            if b.nombre == nombre:
                messagebox.showerror("Error", "Ya existe un barco con ese nombre.")
                return

        try:
            px = int(simpledialog.askstring("Nuevo Barco", "Posición X (ej: 100):", parent=self.root))
            py = int(simpledialog.askstring("Nuevo Barco", "Posición Y (ej: 100):", parent=self.root))
            vel = int(simpledialog.askstring("Nuevo Barco", "Velocidad (0-20):", parent=self.root))
            rum = int(simpledialog.askstring("Nuevo Barco", "Rumbo (1-359):", parent=self.root))
            mun = int(simpledialog.askstring("Nuevo Barco", "Munición (ej: 5):", parent=self.root))
        except (ValueError, TypeError):
            messagebox.showerror("Error", "Entrada inválida. Se cancela la creación.")
            return

        nuevo_barco = Barco(nombre, px, py, vel, rum, mun)
        
        canvas_id = self.canvas.create_image(px, py, image=self.ship_icon, 
                                             anchor=tk.CENTER)
        nuevo_barco.canvas_id = canvas_id
        
        self.lista_barcos.append(nuevo_barco)
        self.actualizar_selector()
        
        self.selector_var.set(nombre)
        self.seleccionar_barco_activo(None) 

    def actualizar_selector(self):
        nombres = [b.nombre for b in self.lista_barcos]
        self.selector_barco['values'] = nombres

    def seleccionar_barco_activo(self, event):
        nombre_seleccionado = self.selector_var.get()
        self.barco_activo = None
        for barco in self.lista_barcos:
            if barco.nombre == nombre_seleccionado:
                self.barco_activo = barco
                break
        
        if self.barco_activo:
            self.habilitar_controles(True)
            self.actualizar_info_barco()
            self.entry_velocidad.delete(0, tk.END)
            self.entry_rumbo.delete(0, tk.END)
            self.entry_municion.delete(0, tk.END)
        else:
            self.habilitar_controles(False)

    def actualizar_info_barco(self):
        if self.barco_activo:
            info = (f"Barco: {self.barco_activo.nombre}\n"
                    f"Vel: {self.barco_activo.velocidad} km/h | Rumbo: {self.barco_activo.rumbo}°\n"
                    f"Munición: {self.barco_activo.numeroMunicion}")
            self.estado_label.config(text=info)
            self.boton_disparar.config(text=f"¡Disparar! ({self.barco_activo.numeroMunicion})")

    def actualizar_barco_velocidad(self):
        if self.barco_activo:
            self.barco_activo.setVelocidad(self.entry_velocidad.get())
            self.entry_velocidad.delete(0, tk.END)
            self.actualizar_info_barco()

    def actualizar_barco_rumbo(self):
        if self.barco_activo:
            self.barco_activo.setRumbo(self.entry_rumbo.get())
            self.entry_rumbo.delete(0, tk.END)
            self.actualizar_info_barco()

    def actualizar_barco_municion(self):
        if self.barco_activo:
            self.barco_activo.agregar_municion(self.entry_municion.get())
            self.entry_municion.delete(0, tk.END)
            self.actualizar_info_barco()

    def llamar_disparar(self):
        if self.barco_activo:
            if self.barco_activo.disparar():
                self.sonido_disparo.play()
                self.actualizar_info_barco()
                
                x, y = self.barco_activo.posicionX, self.barco_activo.posicionY
                disparo_visual = self.canvas.create_oval(x-10, y-10, x+10, y+10, 
                                                         fill="red", outline="orange", width=2)
                self.root.after(200, lambda: self.canvas.delete(disparo_visual))
                
            else:
                messagebox.showwarning("Sin Munición", 
                                       f"¡El barco '{self.barco_activo.nombre}' no tiene munición!")
        
    def actualizar_movimiento(self):
        if not self.lista_barcos:
            self.root.after(50, self.actualizar_movimiento)
            return

        for barco in self.lista_barcos:
            escala_velocidad = barco.velocidad / 20.0 
            rad_rumbo = math.radians(barco.rumbo)
            dx = escala_velocidad * math.sin(rad_rumbo)
            dy = escala_velocidad * -math.cos(rad_rumbo)
            
            barco.posicionX += dx
            barco.posicionY += dy
            
            self.canvas.move(barco.canvas_id, dx, dy)
            
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()

            if canvas_width > 50 and canvas_height > 50: 
                if barco.posicionX > canvas_width:
                    barco.posicionX = 0
                    self.canvas.coords(barco.canvas_id, barco.posicionX, barco.posicionY)
                elif barco.posicionX < 0:
                    barco.posicionX = canvas_width
                    self.canvas.coords(barco.canvas_id, barco.posicionX, barco.posicionY)
                    
                if barco.posicionY > canvas_height:
                    barco.posicionY = 0
                    self.canvas.coords(barco.canvas_id, barco.posicionX, barco.posicionY)
                elif barco.posicionY < 0:
                    barco.posicionY = canvas_height
                    self.canvas.coords(barco.canvas_id, barco.posicionX, barco.posicionY)

        if self.barco_activo:
            self.actualizar_info_barco()

        self.root.after(50, self.actualizar_movimiento)

# --- Bloque principal para ejecutar la GUI ---
if __name__ == "__main__":
    root = tk.Tk()
    app = FlotaApp(root)
    root.mainloop()