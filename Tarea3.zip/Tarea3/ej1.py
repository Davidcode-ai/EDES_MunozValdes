# --- EJERCICIO 1: Clase Barco y Pruebas ---
# Nombre: ejercicio1.py
# Asignatura: Entornos de Desarrollo
# Tema: 3
# Fecha: 06/11/2025

class Barco:
    """
    Representa una embarcación con atributos de posición, movimiento y munición.
    """

    def __init__(self, nombre, posicionX, posicionY, velocidad, rumbo, numeroMunicion):
        """
        Constructor de la clase Barco.
        Inicializa todos los atributos.
        """
        self.nombre = nombre
        self.posicionX = posicionX
        self.posicionY = posicionY
        
        # Usamos los setters para la validación inicial de velocidad y rumbo
        self.velocidad = 0  # Valor inicial antes de la validación
        self.rumbo = 1      # Valor inicial antes de la validación
        self.setVelocidad(velocidad)
        self.setRumbo(rumbo)
        
        self.numeroMunicion = numeroMunicion
        print(f"Barco '{self.nombre}' creado en ({self.posicionX}, {self.posicionY}).")

    def __str__(self):
        """
        Método especial __str__
        Devuelve una representación en cadena de texto del estado actual del barco.
        """
        return (f"--- Barco: {self.nombre} ---\n"
                f"  Posición: ({self.posicionX}, {self.posicionY})\n"
                f"  Velocidad: {self.velocidad} km/h\n"
                f"  Rumbo: {self.rumbo}°\n"
                f"  Munición: {self.numeroMunicion} proyectiles\n"
                f"-----------------------")

    def disparar(self):
        """
        Simula un disparo.
        Imprime un mensaje y reduce la munición si hay disponible.
        """
        if self.numeroMunicion > 0:
            print(f"¡El barco '{self.nombre}' ha disparado! *¡BOOM!*")
            self.numeroMunicion -= 1
        else:
            print(f"El barco '{self.nombre}' intenta disparar... ¡pero no tiene munición!")

    def setVelocidad(self, nueva_velocidad):
        """
        Establece una nueva velocidad, validando que esté entre 0 y 20 km/h.
        """
        if 0 <= nueva_velocidad <= 20:
            self.velocidad = nueva_velocidad
            print(f"Velocidad de '{self.nombre}' ajustada a {self.velocidad} km/h.")
        else:
            # Forzamos la velocidad al límite más cercano
            self.velocidad = max(0, min(20, nueva_velocidad))
            print(f"Velocidad solicitada ({nueva_velocidad}) fuera de rango. "
                  f"Ajustada a {self.velocidad} km/h.")

    def setRumbo(self, nuevo_rumbo):
        """
        Establece un nuevo rumbo, validando que esté entre 1 y 359 grados.
        """
        if 1 <= nuevo_rumbo <= 359:
            self.rumbo = nuevo_rumbo
            print(f"Rumbo de '{self.nombre}' ajustado a {self.rumbo}°.")
        else:
            # Forzamos el rumbo al límite más cercano
            self.rumbo = max(1, min(359, nuevo_rumbo))
            print(f"Rumbo solicitado ({nuevo_rumbo}) fuera de rango. "
                  f"Ajustado a {self.rumbo}°.")

# --- Bloque principal para probar la clase ---
if __name__ == "__main__":
    
    # Creación de 3 objetos Barco
    print("--- CREANDO FLOTA ---")
    barco1 = Barco("La Perla Negra", 50, 100, 10, 90, 5)
    barco2 = Barco("El Holandés Errante", 200, 150, 18, 180, 2)
    barco3 = Barco("El Venganza de la Reina Ana", 300, 80, 5, 270, 0)
    print("------------------------\n")

    # --- Pruebas Barco 1 ---
    print("\n*** PRUEBAS BARCO 1: 'La Perla Negra' ***")
    print("--- ESTADO INICIAL ---")
    print(barco1)
    
    print("--- PROBANDO MÉTODOS ---")
    barco1.setVelocidad(15)
    barco1.setRumbo(110)
    barco1.disparar()
    
    print("\n--- ESTADO FINAL ---")
    print(barco1)

    # --- Pruebas Barco 2 ---
    print("\n*** PRUEBAS BARCO 2: 'El Holandés Errante' ***")
    print("--- ESTADO INICIAL ---")
    print(barco2)
    
    print("--- PROBANDO MÉTODOS (CON VALIDACIÓN) ---")
    barco2.setVelocidad(25)  # Prueba de límite superior de velocidad
    barco2.setRumbo(400)   # Prueba de límite superior de rumbo
    barco2.disparar()
    barco2.disparar()
    
    print("\n--- ESTADO FINAL ---")
    print(barco2)

    # --- Pruebas Barco 3 ---
    print("\n*** PRUEBAS BARCO 3: 'El Venganza de la Reina Ana' ***")
    print("--- ESTADO INICIAL ---")
    print(barco3)
    
    print("--- PROBANDO MÉTODOS (SIN MUNICIÓN) ---")
    barco3.setRumbo(45)
    barco3.disparar() # Prueba de disparo sin munición
    
    print("\n--- ESTADO FINAL ---")
    print(barco3)